#!/bin/bash

# Activate the virtual environment
.\env\Scripts\activate
# Run the python script
python goto.py
# Deactivate the virtual environment
deactivate
